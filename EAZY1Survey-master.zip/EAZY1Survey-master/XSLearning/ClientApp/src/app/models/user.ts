export interface Users {
  Username?: string;
  Password?: string;
}
