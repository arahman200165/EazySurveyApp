export interface Response {
  Username?: string;
  SurveyId?: number;
  QuestionId?: number;
  OptionId?: number;
}
