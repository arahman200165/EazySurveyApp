interface Images {
  main: string;
  [key:string]: string;
}
