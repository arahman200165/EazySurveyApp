export interface QuestionInterface {
  surveyTitle : string;
  question : string;
  options: string[];
}
